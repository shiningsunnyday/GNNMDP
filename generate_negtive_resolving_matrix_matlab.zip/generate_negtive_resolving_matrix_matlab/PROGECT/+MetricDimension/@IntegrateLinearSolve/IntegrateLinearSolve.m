classdef IntegrateLinearSolve
    %INTEGRATELINEARSOLVE  conputing the metric dimension of a graph
    %  using  [ResolvingSet, Opt] = solve(obj, ResolvingMatrix )
    
    properties
        demo;
    end
    
    methods
         [ResolvingSet, Opt] = solve(obj, ResolvingMatrix )
    end
    
end

