clear
clc
addpath('D:\PROGECT')
import GRAPH.*

CycleLayer=4;  % ע�⣺ֻ��ȡ 4
CycleOrder=10;  % >=6
T=GRAPH.NewPlot.ConvexPolytopeTnPlot();
Obj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();

Obj_coordinate=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle] =T.TnPlot( CycleLayer, CycleOrder, Obj_adj, Obj_coordinate );
 
 
 
 
 
 
 
 
 
 