clc
clear
addpath('D:\PROGECT')
 import GRAPH.*
 s=[4,10;4,11;4,12;4,13;4,14;4,15;4,16;4,17;4,18;4,19;4,20;...
     4,25;4,30;4,32;4,35;4,40;4,45;4,45;4,50;4,60;4,100];
 [row,col]=size(s);
 for l=1:row
     
cycle_layer= s(l,1);
cycle_order=s(l,2);
n= cycle_layer*cycle_order;


GridObj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
GridObj_dist=GRAPH.GraphParameters.GraphDistanceMatrix();

 [ AdjacentMatrix ] = GridObj_adj.ConvexPolytopeSn( cycle_layer, cycle_order );
 A=cell2mat(AdjacentMatrix);
 [DealAdjacentMatrix] = GridObj_dist.DealMatrix(A);
 [DistanceMatrix]=GridObj_dist.DistanceMatrix (DealAdjacentMatrix);
 GridObj_table=GRAPH.GraphParameters.ResolvingTable();
 [ ResolvingMatrix] =  GridObj_table.ResolvingMatrix(DistanceMatrix);
 [RT2table] =  GridObj_table.GetTable(ResolvingMatrix);
 
  % �����ļ��� grid_data  ,���                              
 dirname=['d:\S_data\S_',num2str(n)];           %�µ��ļ�����
 [a,~,~]=mkdir(dirname);   %��������
 if a~=1
       system(a) ;                    %�����ļ���
 end
 
  
  % ���������txt, ����������

 filename1=['\S_', num2str(n),'_adjacent_matrix.txt'];
 fid1=fopen([dirname,filename1],'wt+');
 [m,n]=size(A);
for k=1:m
     for j=1:n
       if j==n
             fprintf(fid1,'%d\n',A(k,j));
       else
             fprintf(fid1,'%d ',A(k,j)); 
       end
    end
end
fclose(fid1);   
  % ���ֱ����д��txt�ĵ�
 filename2=['\S_', num2str(n),'_resolving_table.txt'];
 fid2=fopen([dirname,filename2],'wt+');
  for i=1:length(RT2table)
   b=cell2mat(RT2table(i));
     for j=1:length(b)
       if j==length(b)
             fprintf(fid2,'%d\n',b(j));
       else
             fprintf(fid2,'%d ',b(j)); 
       end
     end
 end
fclose(fid2);
l

end

 
 







