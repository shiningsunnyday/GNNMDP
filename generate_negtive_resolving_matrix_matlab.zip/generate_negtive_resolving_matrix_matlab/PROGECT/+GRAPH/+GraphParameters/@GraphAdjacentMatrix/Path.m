function [ PathAdjacentMatrix ] = Path( obj, num_vertex )
%Path give the adjacent matrix of path with order num_vertex
%   Input: number vertices num_vertex
%   Output: adjacent matrix 
vector=ones(1,num_vertex-1);
PathAdjacentMatrix=diag(vector,-1)+diag(vector,1);


end

