function  [AdjacentMatrix]=GenerateGraphFromTxt( obj,filename )
%GENERATEGRAPHFROMTXT read adjacent matrix of graphs from a txt file. Read from the first raw and the 0 clumn.

AdjacentMatrix=dlmread(filename,'',1,0);

end

