function [ adjacent_matrix_cell] = ConvexPolytopeTn( obj, cycle_layer, cycle_order )
%CONVEXPOLYTOPETN �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
 connection_block_matrix=diag(ones(1,cycle_order))+diag(ones(1,cycle_order-1),-1);
 connection_block_matrix(1,cycle_order)=1;
if cycle_layer==2
         % generate cell matrix with cycle_layer*cycle_order
         adjacent_matrix=zeros(cycle_layer*cycle_order);
         adjacent_matrix_cell=mat2cell(adjacent_matrix,[cycle_order,cycle_order],[cycle_order,cycle_order]);
         % fill the cell matrix
        
         for i=1:cycle_layer
                 adjacent_matrix_cell{i,i}=obj.Cycle( cycle_order );
         end
         adjacent_matrix_cell{1, cycle_layer}=connection_block_matrix;
       adjacent_matrix_cell{ cycle_layer,1}=connection_block_matrix';

elseif cycle_layer>=3
        % Recursive calls function Convex_polytope_Sn
        [ adjacent_matrix_cell] = obj.ConvexPolytopeTn( 2, cycle_order );
        for j=3: cycle_layer
                  adjacent_matrix_cell(:,j)={zeros(cycle_order )} ;
                 adjacent_matrix_cell(j,:)={zeros(cycle_order )} ;
                  if j==3
                          adjacent_matrix_cell{j-1,j}=eye(cycle_order );
                          adjacent_matrix_cell{j,j-1}=eye(cycle_order );
                  elseif j==4
                          adjacent_matrix_cell{j-1,j}=connection_block_matrix;
                          adjacent_matrix_cell{j,j-1}=connection_block_matrix';
                  end
                  adjacent_matrix_cell{j,j}=obj.Cycle( cycle_order );
            
        end
      
    
end
end

