function [RandomGraphWithEdgeProb]=GenerateRandomGraph(obj, n, p)
%GENERATERANDOMGRAPH generate connected random graphs with edge probability p

flag=0;
while flag==0
a1=[];
     for i=1:n
         b=randsrc(1,i,[0;1]);
         a=randsrc(1,n-i,[0 1;1-p p]); % pΪ�ߵ����Ӹ��ʣ�n1Ϊ������
         c=[b,a];
         A=[a1;c];
         a1=A;
     end
    A=A+A';
%block_num=0;                                                                    %��ļ�����                                                                     %��ͨ�Ե��жϣ���ֵΪ0��ʾ����ͨ
c=1;                                                                            %��������ŵĳ���
vertex_block_num=zeros(n,1);                                                    %�洢�����ŵ�����
for i=1:n
	for j=(i+1):n
		if A(i,j)==1
			if vertex_block_num(i)==vertex_block_num(j)
				if vertex_block_num(i)==0
					vertex_block_num(i)=c;
					vertex_block_num(j)=c;
					c=c+1;
					%block_num=block_num+1;
				end
			elseif vertex_block_num(i)==0
				  vertex_block_num(i)=vertex_block_num(j);
			elseif vertex_block_num(j)==0
				 vertex_block_num(j)=vertex_block_num(i);
			else
				for k=1:n
					if  vertex_block_num(k)==vertex_block_num(i)
						 vertex_block_num(k)=vertex_block_num(j);
					end
				end
				%block_num=block_num-1;
			end
		end
	end
end
if length(unique( vertex_block_num))<=1 && unique( vertex_block_num)~=0 
    flag=1;
    RandomGraphWithEdgeProb=A;
end

end

end


