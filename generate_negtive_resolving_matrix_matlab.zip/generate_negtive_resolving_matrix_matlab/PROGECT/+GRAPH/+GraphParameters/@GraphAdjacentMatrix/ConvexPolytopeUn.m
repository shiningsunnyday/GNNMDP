function [ AdjacentMatrix ] = ConvexPolytopeUn( obj, CycleLayer, CycleOrder  )
%CONVEXPOLYTOPEUN �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

if CycleLayer==4
         % generate cell matrix with cycle_layer*cycle_order
         AdjacentMatrix=zeros(CycleLayer*CycleOrder);
         AdjacentMatrix=mat2cell(AdjacentMatrix, CycleOrder*ones(1,CycleLayer), CycleOrder*ones(1,CycleLayer));
         % fill the cell matrix
         connection_block_matrix=diag(ones(1,CycleOrder))+diag(ones(1,CycleOrder-1),-1);
         connection_block_matrix(1,CycleOrder)=1;
         for i=1:2
                  AdjacentMatrix{i,i}=obj.Cycle( CycleOrder );
         end
         AdjacentMatrix{1, 2}=eye(CycleOrder );
         AdjacentMatrix{2,1}=eye(CycleOrder );
         AdjacentMatrix{2, 3}=eye(CycleOrder );
         AdjacentMatrix{3,2}=eye(CycleOrder );
         AdjacentMatrix{ 3,CycleLayer}=connection_block_matrix;
         AdjacentMatrix{ CycleLayer,3}=connection_block_matrix';

elseif CycleLayer>=5
        % Recursive calls function Convex_polytope_Sn
        [ AdjacentMatrix] = obj.ConvexPolytopeUn( 4, CycleOrder );
        for j=5: CycleLayer
                  AdjacentMatrix(:,j)={zeros(CycleOrder )} ;
                  AdjacentMatrix(j,:)={zeros(CycleOrder )} ;
                  AdjacentMatrix{j-1,j}=eye(CycleOrder );
                  AdjacentMatrix{j,j-1}=eye(CycleOrder );
                  AdjacentMatrix{j,j}=obj.Cycle( CycleOrder );
            
        end
      
    
end
end

