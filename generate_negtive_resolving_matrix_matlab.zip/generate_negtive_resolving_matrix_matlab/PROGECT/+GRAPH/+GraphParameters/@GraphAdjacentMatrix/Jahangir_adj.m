function [ Jahangir_adj_matrix] = Jahangir_adj(obj,N)
%FAN_SUBDIVISION_ADJ Summary of this function goes here
%   Detailed explanation goes here
% nΪż��n=2*k, k�Ƿ�����
L=N;
V=ones(1,L-1);
A1=diag(V,-1);
A2=diag(V,1);
A3=A1+A2;
A3(N,1)=1;
A3(1,N)=1;
for i=1:2:L
    A3(L+1,i)=1;
    A3(i,L+1)=1;
end
Jahangir_adj_matrix=A3;
end

