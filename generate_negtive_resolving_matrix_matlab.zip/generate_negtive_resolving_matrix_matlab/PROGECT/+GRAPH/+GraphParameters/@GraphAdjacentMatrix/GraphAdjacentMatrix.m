classdef GraphAdjacentMatrix<handle
    %GRAPHADJACENTMATRIX �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        
    end
    
    methods
           [ output_cycle ] = Cycle(obj, num_vertex );
           [ adjacent_matrix ] = ConvexPolytopeSn( obj, cycle_layer, cycle_order );
           [ AdjacentMatrix ] = ConvexPolytopeUn( obj, CycleLayer, CycleOrder  )
           [RandomAdjacentMatrix]=ConnectedRandomAdjacentMatrix(obj, n);
           [ PathAdjacentMatrix ] = Path( obj, num_vertex );
           [ adjacent_matrix_cell ] =Grid( obj, raw_layer, col_order );
           [ OneBranch_adj ] = OneBranchBladeAdjacentMatrix(obj,bladeWidth, bladeLength);
           [RandomGraphWithEdgeProb]=GenerateRandomGraph(obj, n, p);
           [AdjacentMatrix]=GenerateGraphFromTxt( obj, filename );
           [ Jahangir_adj_matrix] = Jahangir_adj(obj, N);
        
    end
    
end

