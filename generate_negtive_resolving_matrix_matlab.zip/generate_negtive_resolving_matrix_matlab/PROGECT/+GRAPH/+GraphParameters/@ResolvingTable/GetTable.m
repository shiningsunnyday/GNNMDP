function [RT2table] = GetTable(obj, ResolvingMatrix)
%VERTEXANDVERTEXPAIRSTABLE  gives the Vertex-Pair resolving table of a graph, using ResolvingMatrix;
% 

[~,col]=size(ResolvingMatrix);
RT2table=cell(col,1);
for i=1:col
    RT2table{i}=find(ResolvingMatrix(:,i)~=0)';
end
end

