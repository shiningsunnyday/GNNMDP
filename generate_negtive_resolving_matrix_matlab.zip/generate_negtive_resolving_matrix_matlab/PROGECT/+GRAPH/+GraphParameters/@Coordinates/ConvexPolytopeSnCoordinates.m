function [ x,y ] =ConvexPolytopeSnCoordinates(obj, CycleLayer,CycleOrder)
%COORDINATE �˴���ʾ�йش˺�����ժҪ
%   

 data=0: 2*pi/(CycleOrder): 2*pi-2*pi/(CycleOrder);
 
 [ x_layer_1, y_layer_1 ] = obj.SimpleCoordinate( data );
 [ x_layer_2, y_layer_2 ] = obj.SimpleCoordinate( data+pi/CycleOrder );
%  [ x_layer_3, y_layer_3 ] = obj.SimpleCoordinate( data+pi*.85/CycleOrder );
 
 x=x_layer_1*(1/CycleLayer);
 y=y_layer_1*(1/CycleLayer);
 
  for NC2=2: CycleLayer
       x=[x;x_layer_2*(NC2/CycleLayer)];
       y=[y;y_layer_2*(NC2/CycleLayer)];
  end
 
end

