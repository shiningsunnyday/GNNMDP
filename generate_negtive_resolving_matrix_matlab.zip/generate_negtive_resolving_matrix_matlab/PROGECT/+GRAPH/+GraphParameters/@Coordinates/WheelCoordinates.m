function [Coordinate_x, Coordinate_y] = WheelCoordinates(obj, n)

t=0:2*pi/(n-1):2*pi;
t=t(1:(n-1));
Coordinate_x=sin(t);   
Coordinate_y=cos(t);   
Coordinate_x=[Coordinate_x 0];
Coordinate_y=[Coordinate_y 0];

end

