function [ x,y] =ConvexPolytopeUnCoordinates(obj, CycleLayer,CycleOrder)
%CONVEXPOLYTOPEUNCOORDINATES �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

data=0: 2*pi/(CycleOrder): 2*pi-2*pi/(CycleOrder);
 
 [ x_layer_1, y_layer_1 ] = obj.SimpleCoordinate( data );
 x_layer_2=x_layer_1*(2/CycleLayer );
 y_layer_2 = y_layer_1*(2/CycleLayer );
 x_layer_3=x_layer_1*(3/CycleLayer );
 y_layer_3 = y_layer_1*(3/CycleLayer );
 
 [ x_layer_4, y_layer_4 ] = obj.SimpleCoordinate( data+pi/CycleOrder );
 x_layer_4=x_layer_4*4/CycleLayer;
 y_layer_4 =y_layer_4*4/CycleLayer;
 
 [ x_layer_5, y_layer_5 ] = obj.SimpleCoordinate( data+pi*1.01/CycleOrder );
 x_layer_5=x_layer_5*5/(CycleLayer);
 y_layer_5 =y_layer_5*5/(CycleLayer);
 
 x_layer_1=x_layer_1*(1/CycleLayer);
 y_layer_1=y_layer_1*(1/CycleLayer);
 
 x=[ x_layer_1;x_layer_2; x_layer_3; x_layer_4;x_layer_5];
 y=[ y_layer_1;y_layer_2; y_layer_3; y_layer_4; y_layer_5];
 
  for NC2=6: CycleLayer
       x=[x;x_layer_5*((NC2-4)/(CycleLayer-5))];
       y=[y;y_layer_5*((NC2-4)/(CycleLayer-5))];
  end

end

