classdef Coordinates<handle
    %COORDINATES collects the coordinates of graphs according to the feature
    %  of adjacent matrix of graphs
    %   input: Type of graph
    %   output: coordinates of graphs
    
    properties
    end
    
    methods
        [blade_coordinates ] = BladeCoordinates( obj, cycleLength,bladeWideth,bladeLength);
        [Coordinate_x, Coordinate_y] = WheelCoordinates(obj, n);
        [ x,y] =ConvexPolytopeSnCoordinates(obj, CycleLayer,CycleOrder);
        [ x,y] =ConvexPolytopeUnCoordinates(obj, CycleLayer,CycleOrder);
        [ x,y] = CoordinatesTn( obj, CycleLayer,CycleOrder )
        [ x, y ] = RandomCoordinates(obj, n );
        [ x,y ] = SimpleCoordinate(obj, data  );
        [ x, y ] = GridCoordinates(obj, X);
        [ Coordinates,Coordinates_average,Radius ] = ScatterVertexCoordinates(obj,classes, mean_value, std );
    end
    
end

