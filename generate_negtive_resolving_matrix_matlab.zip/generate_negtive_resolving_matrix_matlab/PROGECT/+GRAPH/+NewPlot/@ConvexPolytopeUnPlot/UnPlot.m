function [ adj_table_handle,f ] = UnPlot( obj, CycleLayer, CycleOrder, Obj_adj, Obj_coordinate)
%SNPLOT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[ adjacent_matrix_cell ] = Obj_adj.ConvexPolytopeUn( CycleLayer, CycleOrder );
[ x,y] = Obj_coordinate.ConvexPolytopeUnCoordinates(CycleLayer,CycleOrder);
% Plot picture
f=figure(1);
set(f, 'color', 'w')
[~, adj_table_handle]=obj.MyPlot(x, y, cell2mat(adjacent_matrix_cell));
% set( adj_table_handle{6,1},'Markersize',18,'Color', 'r')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ο�
% for label=1: length(x)
%     str2=num2str(label);
%     text( x(label)*1.08, y(label)*1.08,  str2, 'HorizontalAlignment' ,'center',  'Interpreter', 'latex', 'Fontsize', 10);
% end
%  axis([-1 1 -1 1])
%  axis off
end

