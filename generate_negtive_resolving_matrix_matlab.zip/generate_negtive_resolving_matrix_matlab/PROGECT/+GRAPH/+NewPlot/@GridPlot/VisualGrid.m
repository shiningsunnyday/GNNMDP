function [ adj_table_handle] = VisualGrid(obj, GridSize, GridObj, CoordinateObj)
%VISUALGRID �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
RawLayer=GridSize(1);
ColLayer=GridSize(2);
% n=RawLayer*ColLayer;

[ adjacent_matrix_cell ] =GridObj.Grid(RawLayer, ColLayer );

[ x, y ] = CoordinateObj.GridCoordinates(GridSize);
% Un ͼ�Ŀ��ӻ�

f=figure(1);
set(f, 'color', 'w')
[~, adj_table_handle]=obj.MyPlot(x, y, cell2mat(adjacent_matrix_cell));
% set( adj_table_handle{2,1},'Markersize',18,'Color', 'r')


end

