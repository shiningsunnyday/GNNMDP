classdef PartitionPlot<handle
    %PARTITIONPLOT �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        color_vector;
    end
    
    methods
        function obj=PartitionPlot( color_vector)
            if nargin==1
                obj.color_vector=color_vector;
            elseif nargin==0
                obj.color_vector=['r', 'g', 'b', 'c', 'm', 'y', 'k', 'w'];
            end
        end
     end
    methods
        [ out ] = PPlot( obj, vertex_handle, pd_classes );
    end
end

