classdef MyGraphPlot<handle
    %GRAPHPLOT �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        AdjacentMatrix;
    end
    methods
        function obj=MyGraphPlot()
            obj.AdjacentMatrix=[];
        end
    end
    methods
        [adj_table, adj_table_handle]=MyPlot(obj,coordinate_x, coordinate_y, AdjacentMatrix);
        [ adj_table] = adjcent_table(obj,AdjacentMatrix);
        [ adj_table_handle] =adjcent_table_graph(obj,adj_table,x,y);
        
    end
    
end

