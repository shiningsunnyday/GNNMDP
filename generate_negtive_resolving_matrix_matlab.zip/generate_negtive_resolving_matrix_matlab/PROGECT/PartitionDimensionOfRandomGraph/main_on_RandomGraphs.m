% Clearing all
clear;
clc;

% import package GRAPH
addpath('D:\PROGECT')
% �����漴ͼ
load('RandomGraphData/data.mat')

EdgeProb=0.1:.1:.9;

% ����
sd=[9,10,20,34,40,42,50,60,65,70,80,85,88,100,108,120,104,99,90,83];
for j=15:20
     rand('seed',sd(j));   
     
     %   �����ļ��� results
     dirname=['ExperimentResoultsDiscrete' num2str(j) '/'];            %�µ��ļ�����
     [a,~,~]=mkdir(dirname);   %��������
     if a~=1
         system(a) ;                     %�����ļ���
     end
     
     % ��������
     N_pop=100;                     % Population
     Pc=0.85;                              % �������
     Pm=0.1;                            % Mutation probability
     iter=1;                               % ����������ֵ
     iter_max=1000;                 % ����������
     RP=0.2;                             % �ظ�����������Ʋ���
     %�������
     D1=GRAPH.GraphParameters.GraphDistanceMatrix();
     % ���� 9 ���ͼ�Ļ���ά�������������� results �ļ����µ� �ļ���
     for i=1:length(EdgeProb)
          VertexOrder=size(RGraphs{i},1);
          [DistanceMatrix]=D1.DistanceMatrix ( RGraphs{i});
          % �����Ŵ��㷨������� �������㻮�ֶ���ά���ͷֱ滮��
          R=PartitionDimension.GeneticSolve();
          %R=PartitionDimension.NoReplaceIndGeneticSolve(N_pop, Pm,iter, iter_max, RP);
          tic;
          [pd, ~, pd_classes,~,Opt_array] = R.GA_solve(DistanceMatrix,N_pop,iter,iter_max,Pm,RP,Pc);
          %[pd, Opt_array] = R.NRIGA_solve(DistanceMatrix);
          %����ÿ�����е����Ž��
           save(['ExperimentResoultsDiscrete' num2str(j) '/OptValue' num2str(i) '.mat'], 'Opt_array');
          t1=toc;
          temp1=find(Opt_array~=0);
          Opt=Opt_array(temp1);
          average_time=t1/length(Opt);
          NewOrder=[];
          for k=1: length(pd_classes)
              temp=pd_classes{k}(:);
              NewOrder=[NewOrder;temp];
          end
          NewAdjacentMatrix=RGraphs{i}(NewOrder,:);
          % ���ֵĿ��ӻ�
          f1=figure(i);
          set(f1, 'color', 'w');
          PartitionPlot=GRAPH.NewPlot.MyGraphPlot();
          Obj_coordinate=GRAPH.GraphParameters.Coordinates();
          [ Coordinates, Coordinates_average,Radius ] = Obj_coordinate.ScatterVertexCoordinates(pd_classes, pi, .1);
          [~, ~]=PartitionPlot.MyPlot(Coordinates(:,1), Coordinates(:,2),NewAdjacentMatrix);
          
          % ���໭ͼ
          for l=1:size(Coordinates_average,1)
              theta=0:0.1:2*pi;
              Circle1=Coordinates_average(l,1)+Radius(l,1)*cos(theta);
              Circle2=Coordinates_average(l,2)+Radius(l,1)*sin(theta);
              plot(Circle1,Circle2,'--', 'LineWidth', 1);
              str=['$S_{' num2str(l) '}$'];
              c=0.07;
              if Coordinates_average(l,1)>=0 && Coordinates_average(l,2)>=0
                  text( Coordinates_average(l,1)+Radius(l,1)*cos(pi/4)+c,Coordinates_average(l,2)+Radius(l,1)*sin(pi/4)+c,...
                      str, 'HorizontalAlignment' ,'center',  'Interpreter', 'latex', 'Fontsize', 10);
              elseif Coordinates_average(l,1)<0 && Coordinates_average(l,2)>=0
                  text( Coordinates_average(l,1)+Radius(l,1)*cos(pi*3/4)-c,Coordinates_average(l,2)+Radius(l,1)*sin(pi*3/4)+c,...
                      str, 'HorizontalAlignment' ,'center',  'Interpreter', 'latex', 'Fontsize', 10);
              elseif  Coordinates_average(l,1)<0 && Coordinates_average(l,2)<=0
                  text( Coordinates_average(l,1)+Radius(l,1)*cos(pi*5/4)-c,Coordinates_average(l,2)+Radius(l,1)*sin(pi*5/4)-c,...
                      str, 'HorizontalAlignment' ,'center',  'Interpreter', 'latex', 'Fontsize', 10);
              elseif Coordinates_average(l,1)>0 && Coordinates_average(l,2)<=0
                  text( Coordinates_average(l,1)+Radius(l,1)*cos(pi*7/4)+c,Coordinates_average(l,2)+Radius(l,1)*sin(pi*7/4)-c,...
                      str, 'HorizontalAlignment' ,'center',  'Interpreter', 'latex', 'Fontsize', 10);
              end
          end
          % �������ͼ
          savefig(f1,['ExperimentResoultsDiscrete' num2str(j) '/Graph' num2str(i) '.fig']);
          close(f1);
          
          % �����Ŀ��ӻ�
          f2=figure(i+1);
          plot(Opt, 'LineWidth', 1);
          xlabel('��������', 'Fontsize', 10);
          ylabel('����ά��', 'Fontsize', 10);
          title('����ά����������', 'Fontsize', 10);
          set(f2, 'color', 'w');
          % �����������
          savefig(f2, ['ExperimentResoultsDiscrete' num2str(j) '/EvaluateCurve' num2str(i) '.fig']);
          close(f2);
          
          %  ����ά��д��
          filename1= ['ExperimentResoultsDiscrete' num2str(j) '/' 'The partition dimension of graph' num2str(i) '.txt'];
          fp1=fopen(filename1, 'w');
          fprintf(fp1,'%s  %s  ', ['The partition dimension of Random Graphs with Order ' num2str(VertexOrder) ' and Edge Probability ' num2str(EdgeProb(i))], 'is ', num2str(pd));  %ע�⣺\r\nΪ���У���ϵͳΪwindows������£�
          fprintf(fp1,'\r\n');
          fprintf(fp1,'%s', ['The average time is ' ],  num2str(average_time));
          fclose(fp1);
          
          %  ���ּ�д��
          filename2= ['ExperimentResoultsDiscrete' num2str(j) '/', 'The minimum resolving partition of graph'  num2str(i) '.txt'];
          fp2=fopen(filename2, 'w');
          fprintf(fp2,'%s  %s  %s  \r\n', 'The minimum resolving partition of ',  ['Random Graphs with Order ' num2str(VertexOrder) ' and Edge Probability ' num2str(EdgeProb(i))], ' is:');
          for m=1:pd
              fprintf(fp2,'%s  %s  \r\n', ['S' num2str(m)  ':'], ['{' num2str(pd_classes{m}) '}']);
          end
          fclose(fp2);
     end
     
end




