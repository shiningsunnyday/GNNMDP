clear
clc
addpath('D:\PROGECT')
import GRAPH.*

% Grid ͼ�Ŀ��ӻ�
subplot(2,2,1)
GridSize= [6,8];
AdjObj1=GRAPH.GraphParameters.GraphAdjacentMatrix();
CoordinateObj1=GRAPH.GraphParameters.Coordinates();
Grid1=GRAPH.NewPlot.GridPlot();
[ adj_table_handle1,~] =Grid1.VisualGrid(GridSize, AdjObj1, CoordinateObj1);
title('(a): $G(6,8)$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.7,.8]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sn ͼ�Ŀ��ӻ�
subplot(2,2,2)
CycleLayer2=4;
CycleOrder2=6;
S=GRAPH.NewPlot.ConvexPolytopeSnPlot();
AdjObj2=GRAPH.GraphParameters.GraphAdjacentMatrix();
CoordinateObj2=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle2, ~] = S.SnPlot( CycleLayer2, CycleOrder2, AdjObj2, CoordinateObj2 );
title('(b): $S_{6}$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.1,-1.3])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Un ͼ�Ŀ��ӻ�
CycleLayer3=5;    %��С�� 5
CycleOrder3=6;   % >= 3
subplot(2,2,3)
U=GRAPH.NewPlot.ConvexPolytopeUnPlot();
AdjObj3=GRAPH.GraphParameters.GraphAdjacentMatrix();
CoordinateObj3=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle3, f3] = U.UnPlot( CycleLayer3, CycleOrder3, AdjObj3, CoordinateObj3 );
title('(c): $U_{6}$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.1,-1.3])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tn ͼ�Ŀ��ӻ�
subplot(2,2,4)
CycleLayer4=4;      % ȡֵ 4
CycleOrder4=6;      % >=3
T=GRAPH.NewPlot.ConvexPolytopeTnPlot();
AdjObj4=GRAPH.GraphParameters.GraphAdjacentMatrix();
Obj_coordinate4=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle4,f4 ] =T.TnPlot( CycleLayer4, CycleOrder4, AdjObj4, Obj_coordinate4 );
title('(d): $T_{6}$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.1,-1.3])
