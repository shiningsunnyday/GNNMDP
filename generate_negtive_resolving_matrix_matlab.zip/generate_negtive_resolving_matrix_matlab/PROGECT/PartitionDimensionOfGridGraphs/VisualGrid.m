

clear
clc
addpath('\PROGECT')
import GRAPH.*
for l=1:100


GridSize= randi([4,5],1,2);
GridObj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
GridObj_dist=GRAPH.GraphParameters.GraphDistanceMatrix();
% д��ʱ��Ҫ��
% CoordinateObj=GRAPH.GraphParameters.Coordinates();
% % Un ͼ�Ŀ��ӻ�
% U=GRAPH.NewPlot.GridPlot();
% [ adj_table_handle] =U.VisualGrid(GridSize, GridObj, CoordinateObj);

 [ AdjacentMatrix ] = GridObj_adj.Grid(  GridSize(1), GridSize(2) );
 A=cell2mat(AdjacentMatrix);
 [DealAdjacentMatrix] = GridObj_dist.DealMatrix(A);
 [DistanceMatrix]=GridObj_dist.DistanceMatrix (DealAdjacentMatrix);
 GridObj_table=GRAPH.GraphParameters.ResolvingTable();
 [ ResolvingMatrix] =  GridObj_table.ResolvingMatrix(DistanceMatrix);
 [RT2table] =  GridObj_table.GetTable(ResolvingMatrix);
  
   % �����ļ��� grid_data  ,���                              
 dirname=['\grid_data\grid_',num2str(GridSize(1)), '_', num2str(GridSize(2))];           %�µ��ļ�����
 [a,~,~]=mkdir(dirname);   %��������
 if a~=1
       system(a) ;                    %�����ļ���
 end
 
  
  % ���������txt, ����������

 filename1=['\grid_', num2str(GridSize(1)), '_', num2str(GridSize(2)),'_adjacent_matrix.txt'];
 fid1=fopen([dirname,filename1],'wt+');
 [m,n]=size(A);
for k=1:m
     for j=1:n
       if j==n
             fprintf(fid1,'%d\n',A(k,j));
       else
             fprintf(fid1,'%d ',A(k,j)); 
       end
    end
end
fclose(fid1);   
  % ���ֱ����д��txt�ĵ�
 filename2=['\grid_', num2str(GridSize(1)), '_', num2str(GridSize(2)),'_resolving_table.txt'];
 fid2=fopen([dirname,filename2],'wt+');
  for i=1:length(RT2table)
   b=cell2mat(RT2table(i));
     for j=1:length(b)
       if j==length(b)
             fprintf(fid2,'%d\n',b(j));
       else
             fprintf(fid2,'%d ',b(j)); 
       end
     end
 end
fclose(fid2);
l

end

 
 
  


  




