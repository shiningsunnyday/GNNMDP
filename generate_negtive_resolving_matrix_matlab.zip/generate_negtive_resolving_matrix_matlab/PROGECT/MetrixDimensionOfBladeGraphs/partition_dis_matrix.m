function [ vertex_dis_partition] = partition_dis_matrix( D,v_number )
%PARTITION_ADJ Summary of this function goes here
%   Detailed explanation goes here
%C=D;
C=D(:,v_number);
A=unique(C);
A_number=length(A)-1;
V=cell(A_number,1);
for i=1:A_number
k=find(C==i)';
V{i,1}=k;
end
vertex_dis_partition=V;
end

