function [ pd, Optmum ] = NGASolve(obj )
%NGASOLVE �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[ AdjacentMatrix_cell ] = obj.Grid(  obj.RawLayer, obj.ColLayer );
[DistanceMatrix]=obj.DistanceMatrix ( cell2mat(AdjacentMatrix_cell));
[pd, Optmum] = obj.NRIGA_solve(DistanceMatrix, obj.N_pop, obj.iter, obj.iter_max, obj.Pm, obj.RP);














end

