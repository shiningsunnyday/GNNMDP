function [newpop]=SinglePointMutation(obj,pop,pm,super) 
     [px,py]=size(pop); 
     newpop=ones(size(pop)); 
     for i=1:px  
         if(rand<pm)         %����һ������������ʱȽ� 
             mpoint=round(rand*py); 
            
             if mpoint<=0 
                  mindex=randsample(1:py,1,true);
                  mpoint=mindex; 
             end
             
             mvalue=randsample(1:super,1,true);
             
             newpop(i,:)=pop(i,:); 
             while any(newpop(i,mpoint))==
             end
             if any(newpop(i,mpoint))==0 
                 newpop(i,mpoint)=1; 
             else
                 newpop(i,mpoint)=0; 
             end
         else
             newpop(i,:)=pop(i,:); 
         end
     end
end
