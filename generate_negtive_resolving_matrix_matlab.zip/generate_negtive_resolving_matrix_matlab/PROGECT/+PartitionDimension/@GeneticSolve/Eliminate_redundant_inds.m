function [ adapt2] = Eliminate_redundant_inds(obj,Pop,adapt,obj_value,R_inds)
%REMOVE_REDUNDANT_INDS Eliminate redundant individuals
adapt2=adapt;
N_rep=ceil(R_inds*size(Pop,1));
for i=2:size(Pop,1)
    temp1=Pop(1:i-1,:);
    temp2=Pop(i,:);
    L1=ismember(temp2,temp1,'rows');
    if L1==1
        adapt2(i)=0;
    else
        temp3= adapt2(1:i-1)~=0;
        temp4=obj_value(temp3);
        L2= ismember(obj_value(i),temp4);
        if L2==1 && length(find(temp4==obj_value(i)))>N_rep
            adapt2(i)=0;
        end
        
    end
    
end

    
    
    
end



% [~,~,n]= unique(Pop,'rows'); % Find all distinct individuals, which are stored in array n
% t=0;
% h=0;
% for i=1:length(n)
%     temp1=find(n==n(i)); % Find all individuals having the same code
%     if length(temp1)>=2
%         t=t+1;
%         temp2=temp1(2:end);% Except one individual
%         
%               adapt2(temp2)=0;% Set the adaptive degree zero for the individuals having the same code except one
%       
%     else
%         temp3=find(obj_value==obj_value(n(i)));% Find all individuals having the same objective value
%         if length(temp3)>N_rep
%             h=h+1;
%             adapt2(temp3(N_rep+1:end))=0;% Set the adaptive degree zero for the redundant individuals
%         end
%     end
% end




% end

