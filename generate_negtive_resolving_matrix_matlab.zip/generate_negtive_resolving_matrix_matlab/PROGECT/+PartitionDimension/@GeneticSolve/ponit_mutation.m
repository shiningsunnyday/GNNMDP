function [ NewPop ] = ponit_mutation(obj,Pop,Pm,super)
%MUTATION �������
%  
[px, py]=size(Pop);
NewPop=ones(px,py);
for i=1:px
    if (rand<Pm)
               mpoint=round(rand*py);
               if mpoint<=0 
                        mpoint=randsample(1:py,1,true);
               end
               NewPop(i,:)=Pop(i,:);
               temp4=randsample(1:super,1,true);
               while NewPop(i,mpoint)==temp4
                         temp4=randsample(1:super,1,true);
               end
               NewPop(i,mpoint)=temp4;
    else
              NewPop(i,:)=Pop(i,:);
    end
    
end
end

