classdef GeneticSolve
    %GENETICSOLVE �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
    end
    
    methods
        [ lower,super] = dimension_bound( obj,DistanceMatrix );
        [ R,index ] = distance_to_subset( obj,ind_partition, DistanceMatrix );
        [ adapt2,t,h] = Eliminate_redundant_inds(obj,Pop,adapt,obj_value,R_inds);
        [ fit,opt_value,opt_ind] = Fitness(obj,Pop, obj_value,R_inds);
        [pd, pd_ind, opt_ind_partition,opt_ind_part,Optmum] = GA_solve(obj,distance_matrix,N_pop,iter,iter_max,Pm,RP,Pc,Tour);
        [ partition,part] = local_partition(obj, ind );
        [ G,t ] = min_coordinate( obj,ind_partition, distance_matrix);
        [ fit,elite] = Modify_fitness(obj, fit );
        [ NewPop ] = ponit_mutation(obj,Pop,Pm,super);
        [ Pop ] = mutation(obj,Pop,Pm,super);
        [ obj_ind_value_temp,Pop] = Object_value( obj,Pop,DistanceMatrix ,super);
        [ partition,part] = partition(obj, Pop );
        [ind,obj_dim] = reduce_dimension(obj,G,ind,ind_partition,ind_part);
        [ newPop] = selection(obj, Pop,adapt );
        [newPop ] = tournament_selection( obj, Pop,adapt,Tour );
        [ ind ] = split_operation(obj, ind,ind_partition,super) ;
        [ NewPop ] = cross(obj, NewPop, Pc);
        [newpop]=SinglePointCross(obj,pop,pc);
         
         
        
        
        
    end
    
end

