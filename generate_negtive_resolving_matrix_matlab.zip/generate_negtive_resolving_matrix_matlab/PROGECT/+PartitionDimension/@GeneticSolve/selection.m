function [ newPop] = selection(obj, Pop,adapt )
%SELECTION �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
[N_pop,c_Pop]=size(Pop);
newPop=zeros(N_pop,c_Pop);
sum_fit=sum(adapt);
fitvalue=adapt./sum_fit;
fitvalue=cumsum(fitvalue);
ms=sort(rand(N_pop,1));
fiti=1;
newi=1;
while newi<=N_pop
    if ms(newi)<fitvalue(fiti)
        newPop(newi,:)=Pop(fiti,:);
        newi=newi+1;
    else
        fiti=fiti+1;
    end
end
end

