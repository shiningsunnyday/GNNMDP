"""
Jian WU
wujian@sxufe.edu.cn
20/12/2020
"""
from __future__ import division
from __future__ import print_function

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pygcn import train_square as ts
from pygcn import utils as ut
from pygcn.models import GCN
import torch.optim as optim

import argparse
import numpy as np
import os
import torch

# Training settings
parser = argparse.ArgumentParser()
parser.add_argument('--no-cuda', action='store_true', default=True,
                    help='Disables CUDA training.')
parser.add_argument('--fastmode', action='store_true', default=False,
                    help='Validate during training pass.')
parser.add_argument('--seed', type=int, default=13, help='Random seed.')
parser.add_argument('--epochs', type=int, default=1000,
                    help='Number of epochs to train.')
parser.add_argument('--Early_stop', type=int, default=1001,
                    help='Early_stop.')
#0.5
parser.add_argument('--lr', type=float, default=0.01,
                    help='Initial learning rate.')
parser.add_argument('--weight_decay', type=float, default=5e-4,
                    help='Weight decay (L2 loss on parameters).')
parser.add_argument('--hidden', type=int, default=32,
                    help='Number of hidden units.')
parser.add_argument('--nclass', type=int, default=1,
                    help='Number of output units.')
parser.add_argument('--batch_size', type=int, default=32,
                    help='Number of batch size for training.')
parser.add_argument('--noisy_size', type=int, default=16,
                    help='Number of batch size for training.')
parser.add_argument('--dropout', type=float, default=0.5,
                    help='Dropout rate (1 - keep probability).')

args = parser.parse_args()
#args.cuda = not args.no_cuda and torch.cuda.is_available()

np.random.seed(args.seed)
torch.manual_seed(args.seed)

# if args.cuda:
#     torch.cuda.manual_seed(args.seed)

# 加载稀疏邻接矩阵和负分辨表
# 加载稀疏邻接矩阵和负分辨表
# U_list = [20,24,28,32,36,40,44,48,52,56,60,64,68,72,76,80,100,120,140,160,180,200,240,400]
# T_list = [68,80,120,200,400]#[20,40,60,88,100,140,200,280,352,396]
C_list =[250,300,352,410,450,520,605,650,700,800]
# 一个图上运行次数

dataset = 'gnm'
execute_times =10

for u in C_list:
    dim_list = []
    resolving_set_list = []
    panel_set_list = []
    time_per_iteration = []
    iteration_list = []

    a= u
    path = "data/random_gnm/adj_natable/"
    dataset1 = "adj_100_{}.txt".format(a)
    dataset2 = "ntable_100_{}.txt".format(a)


    # 运行结果保存路径文件夹
    pathname = 'results/{}/{}/'.format(dataset,a)
    tmep_path = os.path.exists(pathname)
    if not tmep_path:
        os.makedirs(pathname)

    model_save_path = 'results/{}/{}/model_weights'.format(dataset,a)
    tmep_path = os.path.exists(model_save_path)
    if not tmep_path:
        os.makedirs(model_save_path)

    # 训练多次，寻优
    _, \
     normalize_sparse_adj, \
     ntable, \
     idx_train = ut.load_data_adj_ntable(path, dataset1, dataset2)

    # seed_list = [12,13,123,128,23,45,369,99,1234,1238]
    for i in range(execute_times):
        # args.seed = seed_list[i]
        # np.random.seed(args.seed)
        # torch.manual_seed(args.seed)
        # Model and optimizer
        model = GCN(nfeat=args.noisy_size,
                    nhid=args.hidden,
                    nclass=args.nclass,
                    dropout=args.dropout)
        optimizer = optim.Adam(model.parameters(), lr=args.lr, weight_decay=args.weight_decay)
        scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=100, gamma=0.5)# 50,0.1

        # 记录每个网格图迭代的结果
        print('waitting......iteration = ', i)

        ave_time_per_iteration, solution_iteration, \
        episode_origin_mean_reward, episode_new_mean_reward, episode_loss, \
        global_best_ind, global_best_ind_panel_set, global_max_reward, \
        global_ind, global_panel_set, global_rewards \
            = ts.train(args,model,optimizer,scheduler,ntable,normalize_sparse_adj,model_save_path,i)
        # scheduler.step()

        # 记录每次结果
        if len(global_best_ind)!=0:
            dim_list.append(len(global_best_ind))
            resolving_set_list.append(global_best_ind)
            panel_set_list.append(global_best_ind_panel_set)
            time_per_iteration.append(ave_time_per_iteration)
            iteration_list.append(solution_iteration)

        # 每代平均奖励曲线
        plt.figure()
        fig_output_filename1 = "/reward_{}_{}_100_{}.pdf".format(dataset,a,i)
        plt.plot(episode_origin_mean_reward, label="Reward")
        plt.xlabel('Episode')
        plt.ylabel('Reward')
        plt.title('Episode mean reward curve')
        plt.savefig(pathname + fig_output_filename1)
        plt.close()

        plt.figure()
        fig_output_filename11 = "/reward_{}_{}_100_{}.eps".format(dataset,a,i)
        plt.plot(episode_origin_mean_reward, label="Reward")
        plt.xlabel('Episode')
        plt.ylabel(' Reward')
        plt.title('Episode mean reward curve')
        plt.savefig(pathname + fig_output_filename11)
        plt.close()

        # # 每代重构奖励
        # plt.figure()
        # fig_output_filename2 = "/S_reward_U_{}_{}.pdf".format(a, i)
        # plt.plot(episode_new_mean_reward, label="S-reward")
        # plt.xlabel('Episode')
        # plt.ylabel('Reward')
        # plt.title(' S-reward curve')
        # plt.savefig(pathname + fig_output_filename2)
        # plt.close()
        #
        # plt.figure()
        # fig_output_filename22 = "/S_reward_U_{}_{}.eps".format(a, i)
        # plt.plot(episode_new_mean_reward, label="S-reward")
        # plt.xlabel('Episode')
        # plt.ylabel('Reward')
        # plt.title('S-reward curve')
        # plt.savefig(pathname + fig_output_filename22)
        # plt.close()

        # 每代平均损失
        plt.figure()
        fig_output_filename3 = "/policy_loss_{}_{}_100_{}.pdf".format(dataset, a,i)
        plt.plot(episode_loss, label="Policy loss")
        plt.xlabel('Episode')
        plt.ylabel('Loss')
        plt.title('Episode policy loss curve')
        plt.savefig(pathname + fig_output_filename3)
        plt.close()

        plt.figure()
        fig_output_filename33 = "/policy_loss_{}_{}_100_{}.eps".format(dataset, a,i)
        plt.plot(episode_loss, label="Policy loss")
        plt.xlabel('Episode')
        plt.ylabel('Loss')
        plt.title('Episode policy loss curve')
        plt.savefig(pathname + fig_output_filename33)
        plt.close()

        # 每代的全局奖励，即最优奖励曲线
        plt.figure()
        fig_output_filename4 = "/global_rewards_{}_{}_100_{}.pdf".format(dataset,a, i)
        plt.plot(global_rewards, label="Global reward")
        plt.xlabel('Episode')
        plt.ylabel('Rewards')
        plt.title('Global reward curve')
        plt.savefig(pathname + fig_output_filename4)
        plt.close()

        plt.figure()
        fig_output_filename44 = "/global_rewards_{}_{}_100_{}.eps".format(dataset,a, i)
        plt.plot(global_rewards, label="Global reward")
        plt.xlabel('Episode')
        plt.ylabel('Rewards')
        plt.title('Global reward curve')
        plt.savefig(pathname + fig_output_filename44)
        plt.close()

        # 每代运行结果
        output_filename2 = "/{}_100_{}_record_{}.txt".format(dataset,a, i)
        f2 = open(pathname + output_filename2, 'a+')
        f2.write('------------\n')
        f2.write('metric_dimension_list ={}\n'.
                 format(str(dim_list)))
        f2.write('metric_resolving_set_list ={}\n'.
                 format(str(resolving_set_list)))
        f2.write('panel_set_list ={}\n'.
                 format(str(panel_set_list)))
        f2.write('time_per_iteration ={}\n'.
                 format(str(time_per_iteration)))
        f2.write('iteration_list ={}\n'.
                 format(str(iteration_list)))
        f2.write('global_rewards_list ={}\n'.
                 format(str(global_rewards)))
        f2.write('------------\n')
        f2.close()
        # 搜索完成
    output_filename_total = "/total_record_{}_100_{}.txt".format(dataset,a)
    f3 = open(pathname + output_filename_total, 'a+')
    f3.write('------------\n')
    f3.write('metric_dimension ={}\n'.
             format(str(min(dim_list))))
    f3.write('ave_dimension ={}\n'.
             format(str(sum(dim_list) / execute_times)))
    f3.write('resolving_set ={}\n'.
             format(str(resolving_set_list[dim_list.index(min(dim_list))])))
    f3.write('panel_set ={}\n'.
             format(str(panel_set_list[dim_list.index(min(dim_list))])))
    f3.write('ave_time_per_iteration ={}\n'.
             format(str(sum(time_per_iteration) / execute_times)))
    f3.write('ave_iteration ={}\n'.
             format(str(sum(iteration_list) / execute_times)))
    f3.write('ave_iteration ={}\n'.
             format(str(sum(iteration_list) / execute_times)))
    f3.write('------------\n')
    f3.close()
    print("finished!")




