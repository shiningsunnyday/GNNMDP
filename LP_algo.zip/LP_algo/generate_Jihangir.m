clear
clc
addpath('.\PROGECT')
import GRAPH.*
%J_matrix= [4:50,60,70,80,90,100,120,130,140,150,200,250,300]*2;
% 400 ��ʼ
J_matrix= [200,250,300,400,500]*2;

for j=1:length(J_matrix)
    N=J_matrix(j);
    GridObj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
    GridObj_dist=GRAPH.GraphParameters.GraphDistanceMatrix();
    [ AdjacentMatrix] =GridObj_adj.Jahangir_adj(N);
    A=sparse(AdjacentMatrix);
    [row,col,v] = find(A);
    M=[];
    M=[M;row,col,v];
    [DealAdjacentMatrix] = GridObj_dist.DealMatrix(A);
    [DistanceMatrix]=GridObj_dist.DistanceMatrix (DealAdjacentMatrix);
    GridObj_table=GRAPH.GraphParameters.ResolvingTable();
    [ ResolvingMatrix] =  GridObj_table.ResolvingMatrix(DistanceMatrix);
    resolving_matrix=sparse(ResolvingMatrix);
    [table] =  GridObj_table.GetTable(resolving_matrix);
    negtive_resolving_matrix=~sparse(ResolvingMatrix);
    [nrt_table] =  GridObj_table.GetTable(negtive_resolving_matrix);
    % �����ļ��� grid_data  ,���
    dirname=['J_data\J_',num2str(N)];           %�µ��ļ�����
    [a,~,~]=mkdir(dirname);   %��������
    if a~=1
        system(a) ;                    %�����ļ���
    end
    % ���������txt, ����������
    filename1=['\J_', num2str(N),'_adj.txt'];
    fid1=fopen([dirname,filename1],'wt+');
    [m,n]=size(M);
    for k=1:m
        for j=1:n
            if j==1
                fprintf(fid1,'%10d',M(k,j));
            else
                fprintf(fid1,'%10d',M(k,j));
            end
            if mod(j,n)==0
                fprintf(fid1,'\n');
            end
        end
    end
    fclose(fid1);
    % ���ֱ����д��txt�ĵ�
    filename2=['\J_', num2str(N),'_ntable.txt'];
    fid2=fopen([dirname,filename2],'wt+');
    for i=1:length(nrt_table)
        b=cell2mat(nrt_table(i));
        for j=1:length(b)
            if j==length(b)
                fprintf(fid2,'%d\n',b(j));
            else
                fprintf(fid2,'%d ',b(j));
            end
        end
    end
    fclose(fid2);
    
    filename3=['\J_', num2str(N),'_table.txt'];
    fid3=fopen([dirname,filename3],'wt+');
    for i=1:length(table)
        b=cell2mat(table(i));
        for j=1:length(b)
            if j==length(b)
                fprintf(fid3,'%d\n',b(j));
            else
                fprintf(fid3,'%d ',b(j));
            end
        end
    end
    fclose(fid3);
end



