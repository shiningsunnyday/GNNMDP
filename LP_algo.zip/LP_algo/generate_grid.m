clear
clc

addpath('.\PROGECT')
import GRAPH.*
list=[0,0];
l=0
while l<=5
    GridSize= randi([30,40],1,2)
    if ~ ismember(GridSize,list,'rows')
        l=l+1
        list=[list;GridSize;[GridSize(2),GridSize(1)]];
        list=unique(list,'rows');
        GridObj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
        GridObj_dist=GRAPH.GraphParameters.GraphDistanceMatrix();
        [ AdjacentMatrix ] = GridObj_adj.Grid(  GridSize(1), GridSize(2) );
        A=cell2mat(AdjacentMatrix);
        A=sparse(A);
        [row,col,v] = find(A);
        M=[];
        M=[M;row,col,v];
        [DealAdjacentMatrix] = GridObj_dist.DealMatrix(A);
        [DistanceMatrix]=GridObj_dist.DistanceMatrix (DealAdjacentMatrix);
        GridObj_table=GRAPH.GraphParameters.ResolvingTable();
        [ ResolvingMatrix] =  GridObj_table.ResolvingMatrix(DistanceMatrix);
        negtive_resolving_matrix=~sparse(ResolvingMatrix);
        [nrt_table] =  GridObj_table.GetTable(negtive_resolving_matrix);
   
         % �����ļ��� grid_data  ,���
         dirname=['grid_data\grid_',num2str(GridSize(1)), '_', num2str(GridSize(2))];           %�µ��ļ�����
         [a,~,~]=mkdir(dirname);   %��������
         if a~=1
             system(a) ;                    %�����ļ���
         end
         % ���������txt, ����������
         filename1=['\grid_', num2str(GridSize(1)), '_', num2str(GridSize(2)),'_spm.txt'];
         fid1=fopen([dirname,filename1],'wt+');
         [m,n]=size(M);
         for k=1:m
             for j=1:n
                 if j==1
                     fprintf(fid1,'%10d',M(k,j));
                 else
                     fprintf(fid1,'%10d',M(k,j));
                 end
                 if mod(j,n)==0
                     fprintf(fid1,'\n');
                 end
             end
         end
         fclose(fid1);
         % ���ֱ����д��txt�ĵ�
         filename2=['\grid_', num2str(GridSize(1)), '_', num2str(GridSize(2)),'_nrt.txt'];
         fid2=fopen([dirname,filename2],'wt+');
         for i=1:length(nrt_table)
             b=cell2mat(nrt_table(i));
             for j=1:length(b)
                 if j==length(b)
                     fprintf(fid2,'%d\n',b(j));
                 else
                     fprintf(fid2,'%d ',b(j));
                 end
             end
         end
         fclose(fid2);  
     end
end
% % ��������
% [data1,data2,data3]=textread('grid_data\grid_5_5\grid_5_5_spm.txt','%n%n%n');
% A3=[data1,data2,data3]