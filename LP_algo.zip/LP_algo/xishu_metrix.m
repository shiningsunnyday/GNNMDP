function [ reso_metrix] = xishu_metrix( D )
%XISHU_METRIX Summary of this function goes here
%   Detailed explanation goes here
%C=D;
D0=[];
[hd,hl]=size(D);
for i=1:hd-1
    A=ones(hd-i,hl);
    temp=D(i,:);
for j=1:hd-i
    A(j,:)=temp;
end
D1=D(i+1:hd,:);
D1=abs(D1-A);
D0=[D0;D1];
end
reso_metrix=D0;

end

