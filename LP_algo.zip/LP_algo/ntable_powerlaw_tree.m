clear
clc

addpath('.\PROGECT')
import GRAPH.*

n= 100;
num_graphs = 10;
neigh=[1,2,3,4,5,6,7,8,9,10];
sparse_adj_path = 'random_powerlaw_tree/';
 path2 = 'random_powerlaw_tree/adj_natable/';
 [a,~,~]=mkdir(path2);   %��������
 if a~=1
        system(a) ;                    %�����ļ���
 end
Obj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
Obj_dist=GRAPH.GraphParameters.GraphDistanceMatrix();


 for num=1:length(neigh)
    neigh(num)
    adj_name = ['powerlaw_tree_100_',num2str(neigh(num)),'.txt'];
    filename = [sparse_adj_path ,adj_name];
    
    [Adj_list]=Obj_adj.GenerateGraphFromTxt(filename  );
    
    row =Adj_list(:,1)+1;
    col = Adj_list(:,2)+1;
    v = Adj_list(:,3);
    AdjacentMatrix = sparse(row,col,v);
    [row,col,v] = find(AdjacentMatrix);
    M=[];
    M=[M;row,col,v];
    [DealAdjacentMatrix] = Obj_dist.DealMatrix(AdjacentMatrix);
    [DistanceMatrix]=Obj_dist.DistanceMatrix (DealAdjacentMatrix);
    GridObj_table=GRAPH.GraphParameters.ResolvingTable();
    [ ResolvingMatrix] =  GridObj_table.ResolvingMatrix(DistanceMatrix);
    negtive_resolving_matrix=~sparse(ResolvingMatrix);
    [nrt_table] =  GridObj_table.GetTable(negtive_resolving_matrix);
    
   
    % ���������txt, ����������
    filename1=['adj_100_',num2str(neigh(num)),'.txt'];
   
    fid1=fopen([path2,filename1],'wt+');
    [m,n]=size(M);
    for k=1:m
        for j=1:n
            if j==1
                fprintf(fid1,'%10d',M(k,j));
            else
                fprintf(fid1,'%10d',M(k,j));
            end
            if mod(j,n)==0
                fprintf(fid1,'\n');
            end
        end
    end
    fclose(fid1);
    % ���ֱ����д��txt�ĵ�
    filename2=['ntable_100_',num2str(neigh(num)),'.txt'];
    fid2=fopen([path2,filename2],'wt+');
    for i=1:length(nrt_table)
        b=cell2mat(nrt_table(i));
        for j=1:length(b)
            if j==length(b)
                fprintf(fid2,'%d\n',b(j));
            else
                fprintf(fid2,'%d ',b(j));
            end
        end
    end
    fclose(fid2);
end

        
        
        