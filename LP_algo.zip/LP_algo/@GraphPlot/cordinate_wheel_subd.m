function [x,y] = cordinate_wheel_subd(obj, n)
if obj.q==0
 x=rand(1,n);
 y=10*rand(1,n);   
else
t=0:2*pi/(n-1):2*pi;
t=t(1:(n-1));
x=sin(t);%��Ȧ����
y=cos(t);%
x=[x 0];
y=[y 0];
end

end

