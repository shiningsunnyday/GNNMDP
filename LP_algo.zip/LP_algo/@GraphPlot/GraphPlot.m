classdef GraphPlot<handle
    %GRAPHPLOT �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        q=0;
    end
    
    methods
        function obj=GraphPlot(q)
            obj.q=q;
        end
        [x,y] = cordinate_wheel_subd(obj, n);
        [ out1] = adjcent_table(obj,A);
        [ adj_table_handle] =adjcent_table_graph(obj,n,adj_table,x,y);
        R_set_plot(obj,adj_table_handle,resolving_set);
        R_plot(obj,Adj_matrix,n,metric_base);
        evolution_curve(obj, global_best_value,base);
    end
    
end

