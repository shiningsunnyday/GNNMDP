clear
clc

addpath('.\PROGECT')
import GRAPH.*

dirname=['results/'];            %�µ��ļ�����
     [a,~,~]=mkdir(dirname);   %��������
     if a~=1
         system(a) ;                     %�����ļ���
     end
 sparse_adj_path = 'random_gnm/';   
 
 P = [250,300,352,410,450,520,605,650,700,800];
 for i=10
     
     d = P(i);

 adj_name = ['gnm_100_',num2str(d),'.txt'];
 Obj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
 Obj_dist=GRAPH.GraphParameters.GraphDistanceMatrix();
 filename = [sparse_adj_path ,adj_name];
    
  [Adj_list]=Obj_adj.GenerateGraphFromTxt(filename  );
  row =Adj_list(:,1)+1;
  col = Adj_list(:,2)+1;
  v = Adj_list(:,3);
  adj= sparse(row,col,v);
  % adj = full(adj);
  
% data2 = dir('RandomGraph\*.mat');   %load adjacent matrix of graph G
filename1= ['results/gnm_100.txt'];
 if i == 1
     fp1=fopen(filename1, 'w');
    fprintf(fp1, '%10s      %10s      %20s\r\n', 'Graph', 'dim', 'time');
    fclose(fp1);

 end
% for node = 2:length(data2)+1
% load(['RandomGraph\graph' num2str(node) '.mat']);
% Generating the coefficient metrix for the LP algorithm
[ deal_adj_matrix ] = deal_adj(adj);                                   
[D]=distmetrix(deal_adj_matrix);                                                                                           
[ reso_metrix] = xishu_metrix( D );
coefficient_metrix=-reso_metrix;  
% Solving the LP algorithm for the MDP
tic
[~,dimension] = solve( coefficient_metrix )                   
t=toc;
% ׷��д�룺ͼ��ά����ƽ��ÿ�ε���ʱ��
fp1=fopen(filename1, 'a+');
fprintf(fp1, '%10s       %10s            %20.10f\r\n', ['graph', num2str(d)], num2str(dimension), t);
fclose(fp1);
end
