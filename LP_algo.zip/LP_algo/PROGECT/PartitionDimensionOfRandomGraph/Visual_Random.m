clc
clear
addpath('D:\PROGECT')
 import GRAPH.*
 load('RandomGraphData/data.mat')
% ͼ�Ķ������ͱߴ��ڵĸ���
VertexOrder=100;       %  >=3 ������
i=6;                              %�ڼ���ͼ
prob=0.1:0.1:0.9;         %�ߵĴ��ڸ���
EdgeProb=prob(i);       %  0--1

% Random ͼ�Ŀ��ӻ�
f1=figure(1);
R=GRAPH.NewPlot.MyGraphPlot();
Obj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
RandomGraphWithEdgeProb=RGraphs{i};
% [RandomGraphWithEdgeProb]=Obj_adj.GenerateRandomGraph(VertexOrder, EdgeProb);
Obj_coordinate=GRAPH.GraphParameters.Coordinates();
[coordinate_x, coordinate_y ] = Obj_coordinate.RandomCoordinates(VertexOrder);
[~, ~]=R.MyPlot(coordinate_x, coordinate_y, RandomGraphWithEdgeProb);
% savefig(['results_on_RandomGraphs/RandomGraph' num2str(1) '.fig'], 'f1')






