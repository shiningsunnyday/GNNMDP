function [ adj_table_handle,f ] = TnPlot( obj, CycleLayer, CycleOrder, Obj_adj, Obj_coordinate )
%TNPLOT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[ x,y] =Obj_coordinate .CoordinatesTn(CycleLayer,CycleOrder);
[ adjacent_matrix_cell ] =Obj_adj.ConvexPolytopeTn(CycleLayer, CycleOrder );
% Plot picture
f=figure(1);
set(f, 'color', 'w')
[~, adj_table_handle]=obj.MyPlot(x, y, cell2mat(adjacent_matrix_cell));
end

