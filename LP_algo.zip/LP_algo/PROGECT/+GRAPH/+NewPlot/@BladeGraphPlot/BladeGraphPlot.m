classdef BladeGraphPlot<GRAPH.NewPlot.MyGraphPlot
    %BLADEGRAPHPLOT �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
    end
    
    methods
        function obj=BladeGraphPlot( )
            obj=obj@GRAPH.NewPlot.MyGraphPlot( );
        end
    end
    methods
       [vertex_handle] = BGplot(obj,blade_coordinates,OneBranch_adj,bladeWidth,bladeLength, cycleLength);
    end
    
end

