function [ adj_table_handle,f ] = SnPlot( obj, CycleLayer, CycleOrder, Obj_adj, Obj_coordinate)
%SNPLOT �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��


[ x,y] =Obj_coordinate .ConvexPolytopeSnCoordinates(CycleLayer,CycleOrder);
[ adjacent_matrix_cell ] =Obj_adj.ConvexPolytopeSn(CycleLayer, CycleOrder );
% Plot picture
f=figure(1);
set(f, 'color', 'w')
[~, adj_table_handle]=obj.MyPlot(x, y, cell2mat(adjacent_matrix_cell));
  
%set( adj_table_handle{6,1},'Markersize',18,'Color', 'r')
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%�ο� 
%  axis([-1 1 -1 1])
%  axis off
%  % layer 1
%  plot(x_layer_1*(1/CycleLayer), y_layer_1*(1/CycleLayer), '.', 'Markersize', 12)
%  hold on
% %  % labels of layer 1
% %  for VC1= 1: CycleOrder
% %       % ������±��latex �ַ��� ���ˣ�������������������
% % %        str=['$l_{' num2str(1) ',' num2str(VC1) '}$']; 
% %        str=['$l_{'  num2str(VC1) '}$']; 
% %        text( x_layer_1(VC1)/(CycleLayer+2), y_layer_1(VC1)/(CycleLayer+2),  str,...
% %            'HorizontalAlignment' ,'center', 'Interpreter', 'latex', 'Fontsize', 10);
% %  end
%  % ���ڶ����Ժ�����ж���
%  for NC2=2: CycleLayer
%         plot(x_layer_2*(NC2/CycleLayer), y_layer_2*(NC2/CycleLayer), '.', 'Markersize', 12);
%  
%  end
% %  % Ϊ�ڶ����Ժ�����ж������ӱ�ǩ
% %  for NC3=2: CycleLayer
% %      
% %      for  VC2= 1: CycleOrder
% % %            str2=['$l_{' num2str(NC3) ',' num2str(VC2) '}$']; 
% %                str2=['$l_{'  num2str((NC3-1)*CycleOrder+VC2) '}$']; 
% %                text( x_layer_3(VC2)*((NC3+.2)/CycleLayer), y_layer_3(VC2)*((NC3+.25)/CycleLayer),  str2,...
% %                          'HorizontalAlignment' ,'center',  'Interpreter', 'latex', 'Fontsize', 10);
% %      
% %               
% %      end 
% %  end

end

