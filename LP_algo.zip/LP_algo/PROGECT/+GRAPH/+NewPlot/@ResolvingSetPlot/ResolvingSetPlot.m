classdef ResolvingSetPlot<GRAPH.NewPlot.MyGraphPlot
    %RESOLVINGSETPLOT plots the resolving set of graphs
    % input: resolving set
    % plot
    
    properties
       
    end
    
    methods
        function obj=ResolvingSetPlot( )
            obj=obj@GRAPH.NewPlot.MyGraphPlot( );
        end
     
    end
    methods
        R_plot(obj, Adj_matrix, n, metric_base,Coordiante_x,Coordinate_y);
        R_set_plot(obj,adj_table_handle,resolving_set);
        
        
    end
end

