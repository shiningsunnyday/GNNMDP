function [DealAdjacentMatrix] = DealMatrix(obj, AdjacentMatrix)
%DEAL_ADJ Summary of this function goes here
%���ڽӾ��������ڼ���������
DealAdjacentMatrix=AdjacentMatrix;
n=size(DealAdjacentMatrix,1);
for i=1:n
    for j=i+1:n
        if DealAdjacentMatrix(i,j)==0
            DealAdjacentMatrix(i,j)=inf;
            DealAdjacentMatrix(j,i)=DealAdjacentMatrix(i,j);
        end
    end
end

end

