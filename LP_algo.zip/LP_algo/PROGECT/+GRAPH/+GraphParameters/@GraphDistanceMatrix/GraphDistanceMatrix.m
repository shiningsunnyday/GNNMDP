classdef GraphDistanceMatrix<handle     
%GRAPHDISTANCEMATRIX input adjacent matrix, and output distance matrix of graphs

    
    properties
    end
    
    methods
             [DealAdjacentMatrix] = DealMatrix(obj, AdjacentMatrix);
             [DistanceMatrix]=DistanceMatrix (obj, AdjacentMatrix);
    end
    
end

