function [ adjacent_matrix ] = ConvexPolytopeSn( obj, cycle_layer, cycle_order )
%ConvexPolytopeSn  give the adjacent matrix of Convex Polytope graph Sn 
%   input: the number of cycle_layer>=2, cycle_order>=3
%   output: adjacent matrix cell

if cycle_layer==2
         % generate cell matrix with cycle_layer*cycle_order
         adjacent_matrix=zeros(cycle_layer*cycle_order);
         adjacent_matrix=mat2cell(adjacent_matrix,[cycle_order,cycle_order],[cycle_order,cycle_order]);
         % fill the cell matrix
         connection_block_matrix=diag(ones(1,cycle_order))+diag(ones(1,cycle_order-1),-1);
         connection_block_matrix(1,cycle_order)=1;
         for i=1:cycle_layer
                  adjacent_matrix{i,i}=obj.Cycle( cycle_order );
         end
         adjacent_matrix{1, cycle_layer}=connection_block_matrix;
         adjacent_matrix{ cycle_layer,1}=connection_block_matrix';

elseif cycle_layer>=3
        % Recursive calls function Convex_polytope_Sn
        [ adjacent_matrix] = obj.ConvexPolytopeSn( 2, cycle_order );
        for j=3: cycle_layer
                  adjacent_matrix(:,j)={zeros(cycle_order )} ;
                  adjacent_matrix(j,:)={zeros(cycle_order )} ;
                  adjacent_matrix{j-1,j}=eye(cycle_order );
                  adjacent_matrix{j,j-1}=eye(cycle_order );
                  adjacent_matrix{j,j}=obj.Cycle( cycle_order );
            
        end
      
    
end
end

