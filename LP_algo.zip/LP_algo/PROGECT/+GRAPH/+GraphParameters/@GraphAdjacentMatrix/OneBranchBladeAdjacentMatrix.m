function [ OneBranch_adj ] = OneBranchBladeAdjacentMatrix(obj,bladeWidth, bladeLength)
%   OneBranchBladeAdjacentMatrix gives a bladeWidth*bladeLength +1 graph matrix(grid);
%

L=bladeWidth*bladeLength;
V1=ones(1,L-1);
for i=bladeWidth:bladeWidth:length(V1)
    V1(i)=0;
end
A1=diag(V1,-1);
A2=diag(V1,1);
A3=A1+A2;
V2=ones(1,L-bladeWidth);
A4=diag(V2,-bladeWidth);
A5=diag(V2,bladeWidth);
A6=A4+A5;
A7=A3+A6;
a=zeros(1,bladeWidth*bladeLength);
A7=[a;A7];
b=zeros(bladeWidth*bladeLength+1,1);
A7=[b,A7];
for i=1:bladeWidth
  A7(1,i+1)=1;
  A7(i+1,1)=1;
end
OneBranch_adj=A7;
end

