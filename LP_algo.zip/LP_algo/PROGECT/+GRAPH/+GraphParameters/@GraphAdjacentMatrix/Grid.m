function [ adjacent_matrix_cell ] =Grid( obj, raw_layer, col_order )
% Grid give the adjacent matrix of grid graphs.input: the number of raw_layer>=2, col_order>=2,output: adjacent matrix

if raw_layer==2
         % generate cell matrix with cycle_layer*cycle_order
         adjacent_matrix_cell=zeros(raw_layer*col_order);
         adjacent_matrix_cell=mat2cell(adjacent_matrix_cell,[col_order,col_order],[col_order,col_order]);
         % fill the cell matrix
         for i=1:raw_layer
                  adjacent_matrix_cell{i,i}=obj.Path( col_order );
         end
         adjacent_matrix_cell{1, raw_layer}=eye(col_order );
         adjacent_matrix_cell{ raw_layer,1}=eye(col_order );

elseif raw_layer>=3
        % Recursive calls function Convex_polytope_Sn
        [ adjacent_matrix_cell] = obj.Grid( 2, col_order );
        for j=3: raw_layer
                  adjacent_matrix_cell(:,j)={zeros(col_order )} ;
                  adjacent_matrix_cell(j,:)={zeros(col_order )} ;
                  adjacent_matrix_cell{j-1,j}=eye(col_order );
                  adjacent_matrix_cell{j,j-1}=eye(col_order );
                  adjacent_matrix_cell{j,j}=obj.Path( col_order );
            
        end
      
    
end
end

