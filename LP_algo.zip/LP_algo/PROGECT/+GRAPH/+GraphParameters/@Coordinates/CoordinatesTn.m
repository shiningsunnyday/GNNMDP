function [ x,y] = CoordinatesTn( obj, CycleLayer,CycleOrder )
%COORDINATESTN �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��
data=0: 2*pi/(CycleOrder): 2*pi-2*pi/(CycleOrder);
 x=[];
 y=[];
 [ x_layer_1, y_layer_1 ] = obj.SimpleCoordinate( data );
 [ x_layer_2, y_layer_2 ] = obj.SimpleCoordinate( data+pi/CycleOrder );
[ x_layer_3, y_layer_3 ] = obj.SimpleCoordinate( data+pi*2/CycleOrder );

 
 x_layer_1=x_layer_1*(1/CycleLayer);
 y_layer_1=y_layer_1*(1/CycleLayer);
 
 x=[x; x_layer_1];
 y=[y;y_layer_1];
 
  for NC2=2: 3
       x=[x;x_layer_2*(NC2/CycleLayer)];
       y=[y;y_layer_2*(NC2/CycleLayer)];
  end
 x_layer_4=x_layer_3*(4/CycleLayer);
 y_layer_4=y_layer_3*(4/CycleLayer);
 x=[x; x_layer_4];
 y=[y;y_layer_4];
 
end

