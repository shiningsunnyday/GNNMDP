classdef ResolvingTable<handle
    %RESOLVINGTABLE Output the ResolvingTable of a graph.
    %input AdjacentMatrix or generate Random AdjacentMatrix for a graph
    %Methods of geting a graph, reading a graph.
    
    properties
        AdjacentMatrix;
    end
    
    methods
       
        [ ResolvingMatrix] = ResolvingMatrix(obj, DistanceMatrix);
        [RT2table] = GetTable(obj, ResolvingMatrix);
    end
    
end

