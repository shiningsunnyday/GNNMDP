function [ ResolvingMatrix] = ResolvingMatrix(obj, DistanceMatrix)
% ResolvingMatrix input distance matrix , output ResolvingMatrix of a graph��

[hd,hl]=size(DistanceMatrix);
 ResolvingMatrix=[];
for i=1:hd-1
    A=ones(hd-i,hl);
for j=1:hd-i
    A(j,:)=DistanceMatrix(i,:);
end
D1=DistanceMatrix(i+1:hd,:);
D1=abs(D1-A);
ResolvingMatrix=[ResolvingMatrix;D1];
end
for k=1:hl
    temp=ResolvingMatrix(:,k)~=0;
    ResolvingMatrix(temp,k)=1;
    
end
end

