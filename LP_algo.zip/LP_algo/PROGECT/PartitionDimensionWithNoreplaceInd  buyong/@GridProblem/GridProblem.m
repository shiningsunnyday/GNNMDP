classdef GridProblem<GRAPH.GraphParameters.GraphAdjacentMatrix ...
        & GRAPH.GraphParameters.GraphDistanceMatrix...
        & PartitionDimension.NoReplaceIndGeneticSolve
    %SNADJACENTMATRIX �˴���ʾ�йش����ժҪ
    %   �˴���ʾ��ϸ˵��
    
    properties
        RawLayer=6;
        ColLayer=8;
    end
    
    methods
        function obj=GridProblem(RawLayer, ColLayer, N_pop, Pm,iter, iter_max, RP)
            obj=obj@GRAPH.GraphParameters.GraphAdjacentMatrix();
            obj=obj@GRAPH.GraphParameters.GraphDistanceMatrix();
            obj=obj@PartitionDimension.NoReplaceIndGeneticSolve();
            
            obj.RawLayer=RawLayer;
            obj.ColLayer=ColLayer;
            obj.N_pop=N_pop;
            obj.Pm=Pm;
            obj.iter=iter;
            obj.iter_max=iter_max;
            obj.RP=RP;
                
        
        end
    end
    methods
        [ pd, Optmum ] = NGASolve(obj );
    end
end

