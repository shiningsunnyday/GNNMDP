clc
clear
addpath('D:\PROGECT')
 import GRAPH.*
 
% Ȧ�Ĳ����Ͷ�����
CycleLayer=5;      %��С�� 5
CycleOrder=10;   %��С�� 3

% Un ͼ�Ŀ��ӻ�
U=GRAPH.NewPlot.ConvexPolytopeUnPlot();
Obj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
[ AdjacentMatrix ] = Obj_adj.ConvexPolytopeUn( CycleLayer, CycleOrder  );
Obj_coordinate=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle, f] = U.UnPlot( CycleLayer, CycleOrder, Obj_adj, Obj_coordinate );







