function [ output_args ] = Demo( input_args )
%UNTITLED �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

import GRAPH.*
G1=GraphParameters.GraphAdjacentMatrix();
[Adj]=G1.Cycle(5);
G2=GraphParameters.GraphDistanceMatrix();
D1=G2.DistanceMatrix(Adj)
G3=GraphParameters.ResolvingTable();
R1=G3.ResolvingMatrix(D1);
S=MetricDimension.IntegrateLinearSolve();
[ResolvingSet, Opt] = S.solve(R1 )
end

