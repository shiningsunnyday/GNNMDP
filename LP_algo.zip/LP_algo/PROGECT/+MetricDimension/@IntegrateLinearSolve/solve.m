function [ResolvingSet, Opt] = solve(obj, ResolvingMatrix )
%SOLVE inputs resolving matrix of a graph,outputs resolving set
%   
C=ResolvingMatrix ;
[row,col]=size(ResolvingMatrix );
f = ones(col,1);
intcon = [1:col];
b=-ones(row,1);
lb = zeros(col,1);
ub = ones(col,1);
[X,fval] = intlinprog(f,intcon,-C,b,[],[],lb,ub);%���������滮����
X=X';
ResolvingSet=find(X);
Opt=fval;
end

