function [ NewPop ] = cross(obj, NewPop, Pc)
%CROSS �˴���ʾ�йش˺�����ժҪ
%   ��ɢ����
n=size(NewPop,2);
N_pop=size(NewPop,1);
for i=1:2:N_pop
    if Pc>rand
    sub_ind1=randi([1,2],1,n);
    temp1=find(sub_ind1==2);
    NewPop(i,temp1)=NewPop(i+1,temp1);
    sub_ind2=randi([1,2],1,n);
    temp2=find(sub_ind2==1);
    NewPop(i+1,temp2)=NewPop(i,temp2);
    end
end
end

