function [ lower,super] = dimension_bound(obj, DistanceMatrix )
%DIAMETER_GRAPH give the lower and upper bound of partition dimension of 
%graph G
%  D is a distance matrix of graph G
super=size(DistanceMatrix,1)-max(DistanceMatrix(:))+1;
lower=ceil(log(size(DistanceMatrix,1))/log(max(DistanceMatrix(:))+1));

end

