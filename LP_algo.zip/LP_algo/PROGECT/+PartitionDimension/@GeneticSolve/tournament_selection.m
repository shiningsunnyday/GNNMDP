function [newPop ] = tournament_selection( obj, Pop,adapt,Tour )
%TOURNAMENT_SELECTION �˴���ʾ�йش˺�����ժҪ
%   �˴���ʾ��ϸ˵��

[N_pop,c_Pop]=size(Pop);
newPop=zeros(N_pop,c_Pop);
newi=1;
while newi<=N_pop
    temp1=randsample(N_pop, Tour) ;
    temp2=adapt(temp1,:);
    [~,I] = max(temp2);
    newPop (newi,:)=Pop(I(1),:);
    newi = newi+1;
end

end

