classdef GraphProblem<PartitionDimension.GeneticSolve
    %GRAPHPROBLEM Solves the graph problems by PartitionDimension.GeneticSolve
    %  First, give the parameters for GeneticSolve,
    %  Second,   call the function [ pd, pd_ind, pd_classes,pd_labels,Opt_array ] =...
    %                 SnDimension(obj, G1,D1, CycleLayer2, CycleOrder2);
    
    properties
        N_pop;        % Population
        Pm;              % Mutation probability
        iter;              % ����������ֵ
        iter_max;      % ����������
        RP;               % �ظ�����������Ʋ���
        Pc                 %�������
       
    end
    
    methods
         function obj=GraphProblem(N_pop, Pm,iter, iter_max, RP,Pc)
             if nargin==0
                 obj.N_pop=100;
                 obj.Pm=0.1;
                 obj.iter=1;
                 obj.iter_max=100;
                 obj.RP=0.2;
                 obj.Pc=0.85;
                 
             else
                 obj.N_pop=N_pop;
                 obj.Pm=Pm;
                 obj.iter=iter;
                 obj.iter_max=iter_max;
                 obj.RP=RP;
                 obj.Pc=Pc;
             end
         end
       
    end
    methods
         [ pd, pd_ind, pd_classes,pd_labels,Opt_array ] = Dimension( obj ,AdjacentMatrix , Dist_Obj);
    end
    
end

