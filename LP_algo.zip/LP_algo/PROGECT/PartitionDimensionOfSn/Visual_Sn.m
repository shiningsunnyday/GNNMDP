clc
clear
addpath('D:\PROGECT')
 import GRAPH.*
 
CycleLayer=4;
CycleOrder=20;
n=CycleLayer*CycleOrder;
S=GRAPH.NewPlot.ConvexPolytopeSnPlot();
Obj_adj=GRAPH.GraphParameters.GraphAdjacentMatrix();
Obj_coordinate=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle] = S.SnPlot( CycleLayer, CycleOrder, Obj_adj, Obj_coordinate );







