clear
clc
addpath('D:\PROGECT')
import GRAPH.*
rand('seed', 108);  
% Grid ͼ�Ŀ��ӻ�
subplot(2,2,1)
GridSize= [6,8];
AdjObj1=GRAPH.GraphParameters.GraphAdjacentMatrix();
CoordinateObj1=GRAPH.GraphParameters.Coordinates();
Grid1=GRAPH.NewPlot.GridPlot();
[ adj_table_handle1] =Grid1.VisualGrid(GridSize, AdjObj1, CoordinateObj1);
title('(a): $G(6,8)$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.7,.8]);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Sn ͼ�Ŀ��ӻ�
subplot(2,2,2)
CycleLayer2=4;
CycleOrder2=6;
S=GRAPH.NewPlot.ConvexPolytopeSnPlot();
AdjObj2=GRAPH.GraphParameters.GraphAdjacentMatrix();
CoordinateObj2=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle2] = S.SnPlot( CycleLayer2, CycleOrder2, AdjObj2, CoordinateObj2 );
title('(b): $S_{6}$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.1,-1.3])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Un ͼ�Ŀ��ӻ�
CycleLayer3=5;    %��С�� 5
CycleOrder3=6;   % >= 3
subplot(2,2,3)
U=GRAPH.NewPlot.ConvexPolytopeUnPlot();
AdjObj3=GRAPH.GraphParameters.GraphAdjacentMatrix();
CoordinateObj3=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle3, f3] = U.UnPlot( CycleLayer3, CycleOrder3, AdjObj3, CoordinateObj3 );
title('(c): $U_{6}$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.1,-1.3])
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Tn ͼ�Ŀ��ӻ�
subplot(2,2,4)
CycleLayer4=4;      % ȡֵ 4
CycleOrder4=6;      % >=3
T=GRAPH.NewPlot.ConvexPolytopeTnPlot();
AdjObj4=GRAPH.GraphParameters.GraphAdjacentMatrix();
Obj_coordinate4=GRAPH.GraphParameters.Coordinates();
[ adj_table_handle4] =T.TnPlot( CycleLayer4, CycleOrder4, AdjObj4, Obj_coordinate4 );
title('(d): $T_{6}$', 'Fontsize', 9,  'Interpreter', 'latex','position',[.1,-1.3])

% ��� Grid ͼ�ķֱ滮�ֺ�ά��
Dist_Obj1=GRAPH.GraphParameters.GraphDistanceMatrix();
Problem1=PartitionDimension.GraphProblem(100, 0.1,1, 100, 0.2,.85); % (N_pop, Pm,iter, iter_max, RP)
[ pd1, ~, pd_classes1,~,~ ] =Problem1.Dimension(cell2mat(AdjObj1.Grid(  GridSize(1), GridSize(2) )) , Dist_Obj1);


% ��� Sn ͼ�ķֱ滮�ֺ�ά��
Dist_Obj2=GRAPH.GraphParameters.GraphDistanceMatrix();
Problem2=PartitionDimension.GraphProblem(100, 0.1,1, 100, 0.2,0.85); % (N_pop, Pm,iter, iter_max, RP)
[ pd2, ~, pd_classes2,~,~ ] =Problem2.Dimension(cell2mat(AdjObj2.ConvexPolytopeSn(  CycleLayer2, CycleOrder2 )) , Dist_Obj2);

% ��� Un ͼ�ķֱ滮�ֺ�ά��
Dist_Obj3=GRAPH.GraphParameters.GraphDistanceMatrix();
Problem3=PartitionDimension.GraphProblem(100, 0.1,1, 100, 0.2,0.85); % (N_pop, Pm,iter, iter_max, RP)
[ pd3, ~, pd_classes3,~,~ ] =Problem3.Dimension(cell2mat(AdjObj3.ConvexPolytopeUn(  CycleLayer3, CycleOrder3 )), Dist_Obj3);

% ��� Tn ͼ�ķֱ滮�ֺ�ά��
Dist_Obj4=GRAPH.GraphParameters.GraphDistanceMatrix();
Problem4=PartitionDimension.GraphProblem(100, 0.1,1, 100, 0.2,0.85); % (N_pop, Pm,iter, iter_max, RP)
[ pd4, ~, pd_classes4,~,~ ] =Problem4.Dimension(cell2mat(AdjObj4.ConvexPolytopeTn(  CycleLayer4, CycleOrder4 )), Dist_Obj4);

% Ϊ�ֱ滮����ÿ�������Ӽ���һ����ɫ���ʺϻ���ά����С��ͼ��
color_vector=['r', 'g', 'b', 'c', 'm', 'y', 'k', 'w'];
P=GRAPH.NewPlot.PartitionPlot(color_vector );
[ out1 ] = P.PPlot( adj_table_handle1, pd_classes1 );
[ out2 ] = P.PPlot( adj_table_handle2, pd_classes2 );
[ out3 ] = P.PPlot( adj_table_handle3, pd_classes3 );
[ out4 ] = P.PPlot( adj_table_handle4, pd_classes4 );





