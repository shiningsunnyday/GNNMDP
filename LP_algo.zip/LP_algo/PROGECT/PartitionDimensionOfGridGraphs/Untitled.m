

clc
clear
dirname=['d:\grid_data\grid_',num2str(3), '_', num2str(3)];
filename=['\grid_', num2str(3), '_', num2str(3),'_resolving_table.txt'];


fid=fopen([dirname,filename],'r');

% f=fscanf(fid,'%d \n',)
%     
%    
% %     tline=str2num(tline);
% %     best_data=[best_data;
% % end
% fclose(fid);

tline = fgetl(fid);
 a=tline

% while ischar(tline)
%    
%     %disp(tline)
%     tline = fgetl(fid);
% end

fclose(fid);